import torch.nn as nn
import torch
import math

class newmapnn(nn.Module):

    def __init__(self, large_kernel_size=3, small_kernel_size=3, n_channels=32, n_blocks=2, scaling_factor=4):

        super(newmapnn, self).__init__()
 
        scaling_factor = int(scaling_factor)
        assert scaling_factor in {2, 4, 8}

        self.conv_block1 = ConvolutionalBlock(in_channels=1, out_channels=n_channels, kernel_size=large_kernel_size,
                                              batch_norm=False, activation='PReLu')

        self.residual_blocks = nn.Sequential(
            *[ResidualBlock(kernel_size=small_kernel_size, n_channels=n_channels) for i in range(n_blocks)])


        self.conv_block2 = ConvolutionalBlock(in_channels=n_channels, out_channels=n_channels,
                                              kernel_size=small_kernel_size,
                                              batch_norm=True, activation=None)

        
        n_subpixel_convolution_blocks = int(math.log2(scaling_factor))
        self.subpixel_convolutional_blocks = nn.Sequential(
            *[SubPixelConvolutionalBlock(kernel_size=small_kernel_size, n_channels=n_channels, scaling_factor=2) for i
              in range(n_subpixel_convolution_blocks)])


        self.conv_block3 = ConvolutionalBlock(in_channels=n_channels, out_channels=1, kernel_size=large_kernel_size,
                                              batch_norm=False, activation='Tanh')

    def forward(self, lr_imgs):

        output = self.conv_block1(lr_imgs)  
        residual = output  
        output = self.residual_blocks(output)  
        output = self.conv_block2(output)  
        output = output + residual  
        output = self.subpixel_convolutional_blocks(output)  
        sr_imgs = self.conv_block3(output)  
        return sr_imgs

class PixelShuffle3d(nn.Module):
    '''
    This class is a 3d version of pixelshuffle.
    Reference form some of the opensourcee code in Guthub
    '''
    def __init__(self, scale):

        super().__init__()
        self.scale = scale

    def forward(self, input):
        batch_size, channels, in_depth, in_height, in_width = input.size()
        nOut = channels // self.scale ** 3

        out_depth = in_depth * self.scale
        out_height = in_height * self.scale
        out_width = in_width * self.scale

        input_view = input.contiguous().view(batch_size, nOut, self.scale, self.scale, self.scale, in_depth, in_height, in_width)

        output = input_view.permute(0, 1, 5, 2, 6, 3, 7, 4).contiguous()

        return output.view(batch_size, nOut, out_depth, out_height, out_width)

class SubPixelConvolutionalBlock(nn.Module):


    def __init__(self, kernel_size=3, n_channels=64, scaling_factor=2):

        super(SubPixelConvolutionalBlock, self).__init__()


        self.conv = nn.Conv3d(in_channels=n_channels, out_channels=n_channels * (scaling_factor ** 3),
                              kernel_size=kernel_size, padding=kernel_size // 2,padding_mode='replicate')

        self.pixel_shuffle = PixelShuffle3d(scale=scaling_factor)

        self.prelu = nn.PReLU()

    def forward(self, input):

        output = self.conv(input)  
        output = self.pixel_shuffle(output) 
        output = self.prelu(output)  

        return output

class ResidualBlock(nn.Module):

    def __init__(self, kernel_size=3, n_channels=64):

        super(ResidualBlock, self).__init__()


        self.conv_block1 = ConvolutionalBlock(in_channels=n_channels, out_channels=n_channels, kernel_size=kernel_size,
                                              batch_norm=True, activation='PReLu')

        self.conv_block2 = ConvolutionalBlock(in_channels=n_channels, out_channels=n_channels, kernel_size=kernel_size,
                                              batch_norm=True, activation=None)

    def forward(self, input):

        residual = input  
        output = self.conv_block1(input)  
        output = self.conv_block2(output)  
        output = output + residual  

        return output

class ConvolutionalBlock(nn.Module):

    def __init__(self, in_channels, out_channels, kernel_size, stride=1, batch_norm=False, activation=None):

        super(ConvolutionalBlock, self).__init__()
        if activation is not None:
            activation = activation.lower()
            assert activation in {'prelu', 'leakyrelu', 'tanh'}

        layers = list()

        layers.append(
            nn.Conv3d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=stride,
                      padding=kernel_size // 2,padding_mode='replicate'),)

        if batch_norm is True:
            layers.append(nn.BatchNorm3d(num_features=out_channels))
  
        if activation == 'prelu':
            layers.append(nn.PReLU())
        elif activation == 'leakyrelu':
            layers.append(nn.LeakyReLU(0.2))
        elif activation == 'tanh':
            layers.append(nn.Tanh())
     
        self.conv_block = nn.Sequential(*layers)

    def forward(self, input):
        output = self.conv_block(input)
        return output

