import torch
import pickle
import numpy as np
import torch.nn as nn
import scipy.io as sio
from torch.nn import functional as F
from newmapnn import newmapnn

class newTOMapnn(nn.Module):

    def __init__(self,Mapnn):
        super(newTOMapnn,self).__init__()
        self.Mapnn = Mapnn.eval()
        self.conv1 =ResidualBlock(kernel_size=3, n_channels=1)
        self.conv2 =ResidualBlock(kernel_size=3, n_channels=1)                    
       
    def forward(self,x):
        x=x.view(32,16,64)
        output=torch.zeros([64,32,128]).to(x.device)

        for i in range(int(x.shape[0]/8)):
            for j in range(int(x.shape[1]/8)):
                for k in range(int(x.shape[2]/8)):
                    inp=x[i*8:i*8+8,j*8:j*8+8,k*8:k*8+8]
                    
                    inp=torch.unsqueeze(inp,0)
                    inp=torch.unsqueeze(inp,0)
                    out=self.Mapnn(inp) 
                    out=torch.clamp(out,min=1e-3)
                    out=torch.squeeze(out,0)
                    out=torch.squeeze(out,0)
                    
                    output[i*16:i*16+16,j*16:j*16+16,k*16:k*16+16]=out
        
        output=torch.unsqueeze(output,0)
        output=torch.unsqueeze(output,0)

        output=torch.reshape(output,(-1,1))
        return output

class ConvolutionalBlock(nn.Module):


    def __init__(self, in_channels, out_channels, kernel_size, stride=1, batch_norm=False, activation=None):

        super(ConvolutionalBlock, self).__init__()
        if activation is not None:
            activation = activation.lower()
            assert activation in {'prelu', 'leakyrelu', 'tanh'}

        layers = list()

        layers.append(
            nn.Conv3d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=stride,
                      padding=kernel_size // 2,padding_mode='replicate'),)

        if batch_norm is True:
            layers.append(nn.BatchNorm3d(num_features=out_channels))

        if activation == 'prelu':
            layers.append(nn.PReLU())
        elif activation == 'leakyrelu':
            layers.append(nn.LeakyReLU(0.2))
        elif activation == 'tanh':
            layers.append(nn.Tanh())

        self.conv_block = nn.Sequential(*layers)

    def forward(self, input):
        output = self.conv_block(input)
        return output

class ResidualBlock(nn.Module):


    def __init__(self, kernel_size=3, n_channels=64):

        super(ResidualBlock, self).__init__()


        self.conv_block1 = ConvolutionalBlock(in_channels=n_channels, out_channels=n_channels, kernel_size=kernel_size,
                                              batch_norm=True, activation='PReLu')


        self.conv_block2 = ConvolutionalBlock(in_channels=n_channels, out_channels=n_channels, kernel_size=kernel_size,
                                              batch_norm=True, activation=None)

    def forward(self, input):

        residual = input  
        output = self.conv_block1(input)  
        output = self.conv_block2(output)  
        output = output + residual  

        return output

def load_data():
    c1 = sio.loadmat('E:\PHD-1st-year\A-TO\TopAcc\Python\dataset\\formal\list_x_whole')
    c1 = c1['matrix']
    c2 = sio.loadmat('E:\PHD-1st-year\A-TO\TopAcc\Python\dataset\\formal\list_x2_whole')
    c2 = c2['matrix']

    c1=torch.FloatTensor(c1) 
    c2=torch.FloatTensor(c2) 
    c1=torch.unsqueeze(c1,1) 
    c2=torch.unsqueeze(c2,1) 
    
    return c1,c2

learning_rate=1e-3
epochs=10
batch_size=1
train_number =240
val_number = 30

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
Mapnn=newmapnn(large_kernel_size=3,
                     small_kernel_size=3,
                     n_channels=32,
                     n_blocks=4,
                     scaling_factor=2).to(device)
model_path='Mapnn.pth'
Mapnn.load_state_dict(state_dict=torch.load(model_path))
Mapnn.eval()
model=newTOMapnn(Mapnn).to(device)
criterion = nn.MSELoss(reduction='mean')  
optimizer = torch.optim.Adam(model.parameters(),lr=learning_rate)

train_epochs_loss = []
valid_epochs_loss = []

c1,c2=load_data()

train_data=[(c1[i],c2[i]) for i in range(train_number)]
val_data=[(c1[i],c2[i]) for i in range(train_number,train_number+val_number)]

train_loader=torch.utils.data.DataLoader(train_data,batch_size=batch_size,shuffle=True)
val_loader=torch.utils.data.DataLoader(val_data,batch_size=batch_size,shuffle=True)

if __name__ == '__main__':
    for epoch in range(epochs):
        #==============================train=============================
        model.train()
        train_epoch_loss = []
        for idx,(c1,c2) in enumerate(train_loader,0):
            
            c1=c1.to(device=device)
            c2=c2.to(device=device)

            outputs = model(c2)
            optimizer.zero_grad()
            c1=torch.reshape(c1,(-1,1))

            loss = criterion(outputs,c1)
            loss.backward()
            optimizer.step()
            train_epoch_loss.append(loss.item())
            if idx%10==0:
                print("epoch={}/{},{}/{} of train, loss={}".format(epoch, epochs, idx, len(train_loader),loss.item()))
        train_epochs_loss.append(np.average(train_epoch_loss))
        #==============================valid=============================
        model.eval()
        valid_epoch_loss = []
        for idx,(c1,c2) in enumerate(val_loader,0):
            
            c1=c1.to(device=device)
            c2=c2.to(device=device)
            outputs = model(c2)
            c1=torch.reshape(c1,(-1,1))

            loss = criterion(outputs,c1)
            valid_epoch_loss.append(loss.item())
            if idx%10==0:
                print("epoch={}/{},{}/{} of valid, loss={}".format(epoch, epochs, idx, len(val_loader),loss.item()))
        valid_epochs_loss.append(np.average(valid_epoch_loss))

    File ="TOMapnn.pth"
    torch.save(model.state_dict(),File)

    import matplotlib.pyplot as plt
    plt.plot(np.arange(len(train_epochs_loss)), train_epochs_loss,'r', label="Loss")
    plt.show()
    plt.plot(np.arange(len(valid_epochs_loss)), valid_epochs_loss,'r', label="Loss")
    plt.show()
