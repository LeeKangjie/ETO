from finite_element_analysis import *
from finite_element_analysis2 import *
from numpy import *

global ELEMENT_COUNTS,ELEMENT_ATTRIBUTES,NODE_COORDINATES,NODE_COUNTS,CENTERS,V,DIM,GRID_TYPE,TYPE
global ELEMENT_COUNTS2, ELEMENT_ATTRIBUTES2, NODE_COORDINATES2, NODE_COUNTS2, CENTERS2, V2
global R, E, NU, PENAL, MOVE,VOLFAC

def hyperparameter(r,penal,volfac,move,e,nu):
    global R, E, NU, PENAL, MOVE,VOLFAC
    R=r
    PENAL=penal
    MOVE=move
    E=e
    NU=nu
    VOLFAC = volfac

def initialize_global_variable(type):

    global ELEMENT_COUNTS, ELEMENT_ATTRIBUTES, NODE_COORDINATES, NODE_COUNTS, CENTERS, V, K,DIM,GRID_TYPE,TYPE
    global ELEMENT_COUNTS2, ELEMENT_ATTRIBUTES2, NODE_COORDINATES2, NODE_COUNTS2, CENTERS2, V2
    
    TYPE = type
    if TYPE =='top2d':
        DIM = 8
        GRID_TYPE = 'Polygon'
    if TYPE =='top3d':
        DIM = 24
        GRID_TYPE = 'Hexahedron'
    ANSYS_SOLVER = FiniteElementAnalysis()
    #ANSYS_SOLVER.boot() 
    ELEMENT_COUNTS, NODE_COUNTS = ANSYS_SOLVER.get_counts(ANSYS_SOLVER.awd + 'elements_nodes_counts.txt')
    ELEMENT_ATTRIBUTES, CENTERS, V, NODE_COORDINATES = ANSYS_SOLVER.get_meshmodel_data()
    
    ANSYS_SOLVER2 = FiniteElementAnalysis2()
    #ANSYS_SOLVER2.boot() 
    ELEMENT_COUNTS2, NODE_COUNTS2 = ANSYS_SOLVER2.get_counts(ANSYS_SOLVER2.awd + 'elements_nodes_counts.txt')
    ELEMENT_ATTRIBUTES2, CENTERS2, V2, NODE_COORDINATES2 = ANSYS_SOLVER2.get_meshmodel_data()

    hyperparameter(e =1, nu=0.3, r = 1.2, penal = 3, move = 0.2,volfac = 0.4)
