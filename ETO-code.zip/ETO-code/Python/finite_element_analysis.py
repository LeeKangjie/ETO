import subprocess
import numpy as np
from numpy import *
import re
import global_variable


class FiniteElementAnalysis(object):
    """
    Reference from some of the following opensource link: https://github.com/pep-pig/Topology-optimization-of-structure-via-simp-method
    """
    def __init__(self):

        self.ANSYS_path = "D:\Program Files\ANSYS Inc\\v182\\ansys\\bin\winx64\MAPDL.exe"
        self.awd = 'E:\PHD-1st-year\A-TO\TopAcc\ANSYS/results/'
       

        if global_variable.TYPE == 'top2d':
            self.meshdata_cmd = [self.ANSYS_path, '-b', '-i',
                   'top2d_minf.txt', '-o', 'top2d_minf.out']
            self.result_cmd = [self.ANSYS_path, '-b', '-i',
                   'top2d_rinf.txt', '-o', 'top2d_rinf.out']
            self.dim = global_variable.DIM

        if global_variable.TYPE == 'top3d':
            self.meshdata_cmd = [self.ANSYS_path, '-b', '-i',
                                 'top3d_minf.txt', '-o', 'top3d_minf.out -np 8']
            self.result_cmd = [self.ANSYS_path, '-b', '-i',
                               'top3d_rinf.txt', '-o', 'top3d_rinf.out -np 8']
            self.dim = global_variable.DIM

    def boot(self):
        subprocess.call(self.meshdata_cmd)

    def get_counts(self,element_nodes_file):

        counts = loadtxt(element_nodes_file,dtype = int)
        return counts[0],counts[1]

    def generate_material_properties(self,x):

        nu = global_variable.NU * np.ones((global_variable.ELEMENT_COUNTS))
        ex = (x**global_variable.PENAL)*(global_variable.E)
        material = np.array([nu, ex]).T
        np.savetxt(self.awd+"material.txt", material, fmt=' %-.7E', newline='\n')

    def get_meshmodel_data(self):


        element_attributes = loadtxt(self.awd+'elements_nodes.txt', dtype=int)
        centers = loadtxt(self.awd+'elements_centers.txt')
        v = loadtxt(self.awd+'elements_volumn.txt')
        node_coordinates =loadtxt(self.awd+'node_coordinates.txt')
        return element_attributes,centers,v,node_coordinates

    def get_result_data(self,x):

        self.generate_material_properties(x)
        subprocess.call(self.result_cmd)
        stress = loadtxt(self.awd+'nodal_solution_stress.txt',dtype = float)
        return stress

if __name__=='__main__':
    global_variable.initialize_global_variable('top3d')
    x = 0.4 * np.ones(global_variable.ELEMENT_COUNTS)
    ansys_solver = FiniteElementAnalysis()
    ansys_solver.get_result_data(x=x)

