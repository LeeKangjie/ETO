from numpy import *
import numpy as np
import global_variable
from finite_element_analysis import *
from finite_element_analysis2 import *

from traits.api import HasTraits, Instance, Property, Enum,Range,on_trait_change,Int
import torch.nn.functional as F
import torch
import pickle
from train_mapnn import *

import time

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
Mapnn=newmapnn(large_kernel_size=3,
                     small_kernel_size=3,
                     n_channels=32,
                     n_blocks=4,
                     scaling_factor=2).to(device)

model_path='Mapnn(RSresnet,2times).pth'
Mapnn.load_state_dict(state_dict=torch.load(model_path))
Mapnn.eval()
TOMapnn=TOMapnn(Mapnn).to(device)


Intermodel=nn.Upsample(scale_factor=2, mode='trilinear').to(device)

class Simp(HasTraits):
    loop = Int(0)
    def __init__(self):

        self.ansys_solver = FiniteElementAnalysis()
        self.ansys_solver2 = FiniteElementAnalysis2()
        self.strain_energy = []
        self.volume_rate=[]
        self.volume_rate.append(1)
        self.finished = False
    
    def get_distance_table(self):
        neibors = np.loadtxt(self.ansys_solver.awd+'neibors.txt', dtype=int)
        neiborslist = []
        for i in range(neibors.shape[0]):
            index = neibors[i, np.where(neibors[i, :] > 0)]
            neiborslist.append(index-1)

        coordinates = np.loadtxt(self.ansys_solver.awd+'elements_centers.txt', dtype=float)[:, 1:]
        weights = []
        i = 0
        for neibor in neiborslist:
            b = coordinates[neibor[:]]
            distance = np.sqrt(np.sum((coordinates[neibor,:] - coordinates[i,:]) ** 2, axis=-1))
            weight = (global_variable.R-distance)
            weight[np.where(weight<0)] = 0

            weights.append(weight)
            i = i+1
        return neiborslist,weights

    def get_distance_table_for_smooth(self):
        neibors = np.loadtxt(self.ansys_solver.awd+'neibors.txt', dtype=int)
        neiborslist = []
        for i in range(neibors.shape[0]):
            index = neibors[i, np.where(neibors[i, :] > 0)]
            neiborslist.append(index-1)

        coordinates = np.loadtxt(self.ansys_solver.awd+'elements_centers.txt', dtype=float)[:, 1:]
        weights = []
        i = 0
        for neibor in neiborslist:
            b = coordinates[neibor[:]]
            distance = np.sqrt(np.sum((coordinates[neibor,:] - coordinates[i,:]) ** 2, axis=-1))
            weight = (global_variable.R-distance)

            weight[np.where(weight<0)] = 0

            weights.append(weight)
            i = i+1
        return neiborslist,weights

    def de_checkboard(self,x, dc):
        corrected_dc = []
        i = 0
        x = np.array(x)
        dc = np.array(dc)
        index = np.where(dc<0)
        j = 0
        for _ in dc:
            corrected_dc_demonimator = 0.0
            corrected_dc_numerator = 0.0
            elements =self.neiborslist[j].tolist()[0]
            corrected_dc_demonimator = np.sum(self.weights[j])
            corrected_dc_numerator = np.sum(self.weights[j] * x[elements[:]] * dc[elements[:]])
            corrected_dc.append(corrected_dc_numerator / (x[j] * corrected_dc_demonimator))
            j=j+1
        index = np.where(array(corrected_dc)<0)
        return corrected_dc
   

    def x_smooth(self,x):
        corrected_x=[]
        x = np.array(x)
        j = 0
        for _ in x:           
            corrected_dc_demonimator2 = 0.0
            corrected_dc_numerator2 = 0.0
            elements =self.neiborslist2[j].tolist()[0]
            corrected_dc_demonimator2 = np.sum(self.weights2[j])
            corrected_dc_numerator2 = np.sum(self.weights2[j] * x[elements[:]])
            corrected_x.append(corrected_dc_numerator2 / corrected_dc_demonimator2)
            j=j+1
        corrected_x=np.array(corrected_x)
        return corrected_x


    def get_coordinates(self):
        dc=0.05
        coordinates = np.loadtxt('E:\PHD-1st-year\A-TO\TopAcc\ANSYS/results/elements_centers.txt', dtype=float)[:, 1:]
        coordinates1=abs(1000*coordinates-0.5*1000*dc)//(1000*dc)#
        coordinates1=coordinates1.astype(np.int32)
        dc=0.1
        coordinates = np.loadtxt('E:\PHD-1st-year\A-TO\TopAcc\ANSYS/results/coarse/elements_centers.txt', dtype=float)[:, 1:]
        coordinates2=abs(1000*coordinates-0.5*1000*dc)//(1000*dc)
        coordinates2=coordinates2.astype(np.int32)
        return coordinates1,coordinates2

    def oc(self, x, volfrac, corrected_dc):

        lambda1 = 0; lambda2 = 100000; move = global_variable.MOVE
        while(lambda2-lambda1>1e-4):
            lambda_mid = 0.5*(lambda2+lambda1)
            #index = np.where(array(corrected_dc)<0)
            B = x*sqrt((array(corrected_dc,dtype = float))/(lambda_mid * global_variable.V[:,1]))
            xnew = maximum(0.001, maximum(x-move, minimum(1.0, minimum(x + move,B))))
            if sum(xnew*global_variable.V[:,1])-volfrac*sum(global_variable.V[:,1])>0:
                lambda1 = lambda_mid
            else:
                lambda2 = lambda_mid
        self.volume_rate.append(sum(xnew*global_variable.V[:,1])/sum(global_variable.V[:,1]))
        print("volume rate:" , self.volume_rate[-1])
        return xnew


    def simp(self):
        penal = global_variable.PENAL
        volfrac = global_variable.VOLFAC
        rmin = global_variable.R
        self.neiborslist,self.weights = self.get_distance_table()
        self.neiborslist2,self.weights2 = self.get_distance_table_for_smooth()
        self.coordinates1,self.coordinates2=self.get_coordinates()
        x = volfrac*np.ones(global_variable.ELEMENT_COUNTS)
        x2 = volfrac*np.ones(global_variable.ELEMENT_COUNTS2)
        change_c = change_x = 1
        c_total= 0
        Emin = 1e-9
        list_x=[]
        self.loop=0
        
        while self.loop<20:
            c_old =c_total
            xold = x
           
            #=================================Step1==========================================
            xout=np.full((64,32,128),1e-3)
            xout[self.coordinates1[:,2],self.coordinates1[:,1],self.coordinates1[:,0]]=x
            x=xout

            lx=torch.tensor(x.reshape((64,32,128))).unsqueeze(0).unsqueeze(0)
            x2=F.max_pool3d(lx,kernel_size=2, stride=2, padding=0)

            x2=x2.squeeze(0).squeeze(0)
            x2=x2[self.coordinates2[:,2],self.coordinates2[:,1],self.coordinates2[:,0]]

            x2=x2.numpy()
            x2=x2.reshape((-1,))
            start=time.time()
            stress2 = self.ansys_solver2.get_result_data(x2)
            end=time.time()
            print('once FEM time on coarse grid '+str(end-start))

            cu = np.loadtxt(self.ansys_solver2.awd+'strain_energy.txt',dtype = float)[0:global_variable.ELEMENT_COUNTS2].reshape(global_variable.ELEMENT_COUNTS2,1)*2
            uku = cu/(x2.reshape((global_variable.ELEMENT_COUNTS2,1))**penal)
            dc = (penal*(x2.reshape((global_variable.ELEMENT_COUNTS2,1))** (penal-1)))*uku
            dc = dc[:,0].tolist()
            corrected_dc = self.de_checkboard(x2, dc)
            x2 = self.oc(x2, volfrac, corrected_dc)
            c_total = sum(cu, axis=0)[0]
            #=================================Step2==========================================
            xout=np.full((32,16,64),1e-3)
            xout[self.coordinates2[:,2],self.coordinates2[:,1],self.coordinates2[:,0]]=x2 
            x2=xout.reshape((-1,))

            with torch.no_grad():
                x2=torch.FloatTensor(x2)
                x2=x2.to(device=device)
                x=TOMapnn(x2)
            x=x.cpu().numpy().reshape((-1,))
            x2=x.reshape((64,32,128))
            x=x2[self.coordinates1[:,2],self.coordinates1[:,1],self.coordinates1[:,0]]
            x=self.x_smooth(x)
            x=np.clip(x,a_min=1e-3,a_max=1.0)
           
            #================================Step3=======================================
            change_x = abs(max(x-xold))
            change_c = abs(c_old - c_total)
            self.strain_energy.append(c_total)
            save_x=np.zeros((64,32,128))
            save_x[self.coordinates1[:,2],self.coordinates1[:,1],self.coordinates1[:,0]]=x

            list_x.append(save_x)
            print("c:",c_total,"    loop: ",self.loop,'change_x',change_x)
            self.loop = self.loop + 1
            
            '''
            #todo=============
            stress2 = self.ansys_solver2.get_result_data(x2)
            c = np.loadtxt(self.ansys_solver2.awd+'strain_energy.txt',dtype = float)[0:global_variable.ELEMENT_COUNTS2].reshape(global_variable.ELEMENT_COUNTS2,1)*2
            uku = c/(x2.reshape((global_variable.ELEMENT_COUNTS2,1))**penal)
            dc = (penal*(x2.reshape((global_variable.ELEMENT_COUNTS2,1))** (penal-1)))*uku
            dc = dc[:,0].tolist()
            corrected_dc = self.de_checkboard(x2, dc)
            x2 = self.oc(x2, volfrac, corrected_dc)
            c_total = sum(c, axis=0)[0]
            change_c = abs(c_old - c_total)#cold=ctotal在290行
            change_x = abs(max(x2-xold))
            self.strain_energy.append(c_total)
            if change_c/c_total>0.01:
                save_x=np.full((32,16,64),1e-3)
                save_x[self.coordinates2[:,2],self.coordinates2[:,1],self.coordinates2[:,0]]=x2
                list_x.append(save_x)
            else:
                with torch.no_grad():
                    #x=TOMapnn(x2)
                    xout=np.full((32,16,64),1e-3)
                    xout[self.coordinates2[:,2],self.coordinates2[:,1],self.coordinates2[:,0]]=x2
                    x2=torch.FloatTensor(xout)
                    x2=x2.to(device=device)
                    x2=torch.unsqueeze(x2,0)
                    x2=torch.unsqueeze(x2,0)
                    out=Intermodel(x2)
                    out=torch.clamp(out,min=1e-3)
                    out=torch.squeeze(out,0)
                    out=torch.squeeze(out,0)
                    save_x=out.cpu().numpy()
                    list_x.append(save_x)
                    x=out[self.coordinates1[:,2],self.coordinates1[:,1],self.coordinates1[:,0]]

                x=x.cpu().numpy().reshape((-1,))
                #x=self.x_smooth(x)              
                #stress2 = self.ansys_solver.get_result_data(x)#apdl batch计算结果并写入
                #c = np.loadtxt(self.ansys_solver.awd+'strain_energy.txt',dtype = float)[0:global_variable.ELEMENT_COUNTS].reshape(global_variable.ELEMENT_COUNTS,1)*2
                #c_total = sum(c, axis=0)[0]
                #print('compliance on fine grid',c_total)
                break 
            print("c：",c_total,"    loop: ",self.loop,'change_x',change_x)
            self.loop = self.loop + 1
            '''
        self.finished = True
        return list_x

if __name__=='__main__':
    global_variable.initialize_global_variable('top3d')
    simp_solver = Simp()

    Fx,Fy,Fz=0,0,-1
    locx,locz=64,0

    with open("top3d_var.txt",'w') as f:
        f.write('locx='+str(locx*0.1)+'\n')
        f.write('locy='+str(8*0.1)+'\n') 
        f.write('locz='+str(locz*0.1)+'\n')
        f.write('Fx='+str(Fx)+'\n')
        f.write('Fy='+str(Fy)+'\n')
        f.write('Fz='+str(Fz)+'\n')
    f.close

    start = time.time()
    list_x = simp_solver.simp()
    end = time.time()
    print('excution time: ',end - start)
    f=open('list_x.pkl','wb')
    pickle.dump(list_x,f)
    f.close

