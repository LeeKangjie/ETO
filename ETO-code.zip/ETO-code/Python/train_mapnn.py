import torch
import pickle
import numpy as np
import torch.nn as nn
import scipy.io as sio
from torch.nn import functional as F
from newmapnn import newmapnn

def my_smooth_layer(input):
    K=torch.full((3,3,3),0.037037)
    weight=K.unsqueeze(0).unsqueeze(0)
    output=F.conv3d(input,weight,stride=1, padding=1)
    return output

def conv_block_3d(in_dim,out_dim,act_fn):                                          
    model = nn.Sequential(
        nn.Conv3d(in_dim,out_dim, kernel_size=3, stride=1, padding=1,padding_mode='replicate'),
        nn.BatchNorm3d(out_dim),
        act_fn,
    )
    return model

def conv_trans_block_3d(in_dim,out_dim,act_fn):                                         
    model = nn.Sequential(
        nn.ConvTranspose3d(in_dim,out_dim, kernel_size=3, stride=2, padding=1,output_padding=1),
        nn.BatchNorm3d(out_dim),
        act_fn,
    )
    return model

def maxpool_3d():                                                                      
    pool = nn.MaxPool3d(kernel_size=2, stride=2, padding=0)
    return pool

def conv_block_2_3d(in_dim,out_dim,act_fn):                                            
    model = nn.Sequential(
        conv_block_3d(in_dim,out_dim,act_fn),
        nn.Conv3d(out_dim,out_dim, kernel_size=3, stride=1, padding=1,padding_mode='replicate'),
        nn.BatchNorm3d(out_dim),
        #todo act_fn
    )
    return model   

class Mapnn(nn.Module):

    def __init__(self,in_dim,out_dim,num_filter):
        super(Mapnn,self).__init__()
        self.in_dim = in_dim                                                            
        self.out_dim = out_dim                                                          
        self.num_filter = num_filter                                                   
        act_fn = nn.LeakyReLU(0.2, inplace=True)

        
        self.down_1 = conv_block_2_3d(self.in_dim,self.num_filter,act_fn)                 
        self.pool_1 = maxpool_3d()                                                      
        self.down_2 = conv_block_2_3d(self.num_filter,self.num_filter*2,act_fn)         
        self.pool_2 = maxpool_3d()                                                      
        
        self.bridge = conv_block_2_3d(self.num_filter*2,self.num_filter*4,act_fn)       
        
        self.trans_1 = conv_trans_block_3d(self.num_filter*4,self.num_filter*4,act_fn) 
        self.up_1 = conv_block_2_3d(self.num_filter*6,self.num_filter*2,act_fn)        
        self.trans_2 = conv_trans_block_3d(self.num_filter*2,self.num_filter*2,act_fn)  
        self.up_2 = conv_block_2_3d(self.num_filter*3,self.num_filter,act_fn)      
        self.trans_3 = conv_trans_block_3d(self.num_filter,self.num_filter,act_fn)    
        
        self.out = conv_block_3d(self.num_filter,out_dim,act_fn)                        

    def forward(self,x):
        down_1 = self.down_1(x)                          
        pool_1 = self.pool_1(down_1)                     
        down_2 = self.down_2(pool_1)                     
        pool_2 = self.pool_2(down_2)                     
 
        bridge = self.bridge(pool_2)                    
        
        trans_1  = self.trans_1(bridge)                  
        concat_1 = torch.cat([trans_1,down_2],dim=1)     
        up_1     = self.up_1(concat_1)                   
        trans_2  = self.trans_2(up_1)                    
        concat_2 = torch.cat([trans_2,down_1],dim=1)     
        up_2     = self.up_2(concat_2)                   
        
        trans_3  = self.trans_3(up_2)                  
        out = self.out(trans_3)                          


        return out

def clip_norm(input):
    input2=input.reshape((-1,))
    zuida,_=input2.topk(int(0.005*input2.shape[0]))
    max_clip=torch.min(zuida)
    tinput=-input2
    zuixiao,_=tinput.topk(int(0.005*tinput.shape[0]))
    min_clip=-torch.min(zuixiao)

    output=torch.clamp(input,min=min_clip,max=max_clip)
    output=(output-min_clip)/(max_clip-min_clip)
    return output,min_clip,max_clip

def trans_clip_norm(input,min_clip,max_clip):
    output=(max_clip-min_clip)*input+min_clip
    return output

def std_norm(input):
    input2=input.reshape((input.shape[0],-1))      
    mean=torch.mean(input2,1) 
    std=torch.std(input2,1) 
    mean=mean.reshape(-1,1,1,1,1)
    std=std.reshape(-1,1,1,1,1)
    output=(input-mean)/std 
    return output

class TOMapnn(nn.Module):

    def __init__(self,Mapnn):
        super(TOMapnn,self).__init__()
        self.Mapnn = Mapnn.eval()
       
    def forward(self,x):
        x=x.view(32,16,64)
        output=torch.zeros([64,32,128])

        
        for i in range(int(x.shape[0]/8)):
            for j in range(int(x.shape[1]/8)):
                for k in range(int(x.shape[2]/8)):
                    inp=x[i*8:i*8+8,j*8:j*8+8,k*8:k*8+8]
                
                    inp=torch.unsqueeze(inp,0)
                    inp=torch.unsqueeze(inp,0)
                    out=self.Mapnn(inp) 
                  
                    out=torch.clamp(out,min=1e-3)
                    out=torch.squeeze(out,0)
                    out=torch.squeeze(out,0)
                    
                    output[i*16:i*16+16,j*16:j*16+16,k*16:k*16+16]=out
        output=torch.reshape(output,(-1,1))
        return output

def load_data():

    c1 = sio.loadmat('E:\PHD-1st-year\A-TO\TopAcc\Python\dataset\\formal\list_x')
    c1 = c1['matrix']

    c2 = sio.loadmat('E:\PHD-1st-year\A-TO\TopAcc\Python\dataset\\formal\list_x2')
    c2 = c2['matrix']

    c1=torch.FloatTensor(c1) 
    c2=torch.FloatTensor(c2)
    c1=torch.unsqueeze(c1,1) 
    c2=torch.unsqueeze(c2,1) 
    
    return c1,c2


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
learning_rate=1e-3
epochs=100
batch_size=100
train_number =1800
val_number = 200

c1,c2=load_data()

train_data=[(c1[i],c2[i]) for i in range(train_number)]
val_data=[(c1[i],c2[i]) for i in range(train_number,train_number+val_number)]

train_loader=torch.utils.data.DataLoader(train_data,batch_size=batch_size,shuffle=True)
val_loader=torch.utils.data.DataLoader(val_data,batch_size=batch_size,shuffle=True)


model=newmapnn(large_kernel_size=3,
                     small_kernel_size=3,
                     n_channels=32,
                     n_blocks=4,
                     scaling_factor=4).to(device)

criterion = nn.MSELoss(reduction='mean')
optimizer = torch.optim.Adam(model.parameters(),lr=learning_rate) 

train_epochs_loss = []
valid_epochs_loss = []

if __name__ == '__main__':
   
    for epoch in range(epochs):
        #==============================train=============================
        model.train()
        train_epoch_loss = []
        for idx,(c1,c2) in enumerate(train_loader,0):
            
            c1=c1.to(device=device)
            c2=c2.to(device=device)

            outputs = model(c2)
            optimizer.zero_grad()
            loss = criterion(outputs,c1)
            loss.backward()
            optimizer.step()
            train_epoch_loss.append(loss.item())
            if idx%10==0:
                print("epoch={}/{},{}/{} of train, loss={}".format(epoch, epochs, idx, len(train_loader),loss.item()))
        train_epochs_loss.append(np.average(train_epoch_loss))
        #==============================valid=============================
        model.eval()
        valid_epoch_loss = []
        for idx,(c1,c2) in enumerate(val_loader,0):
            
            c1=c1.to(device=device)
            c2=c2.to(device=device)
            outputs = model(c2)

            loss = criterion(outputs,c1)
            valid_epoch_loss.append(loss.item())
            if idx%10==0:
                print("epoch={}/{},{}/{} of valid, loss={}".format(epoch, epochs, idx, len(val_loader),loss.item()))
        valid_epochs_loss.append(np.average(valid_epoch_loss))

    File ="Mapnn4x(U-net,4times).pth"
    torch.save(model.state_dict(),File)


    file=open('train_epochs_loss2.pickle','wb')
    pickle.dump(train_epochs_loss,file)
    file.close()
    file=open('valid_epochs_loss2.pickle','wb')
    pickle.dump(valid_epochs_loss,file)
    file.close()

    import matplotlib.pyplot as plt
    plt.plot(np.arange(len(train_epochs_loss)), train_epochs_loss,'r', label="Loss")
    plt.show()
    plt.plot(np.arange(len(valid_epochs_loss)), valid_epochs_loss,'r', label="Loss")
    plt.show()
    
